package repository

import (
	_ "github.com/hiddify/hiddify-app-demo-extension/hiddify_extension"
	_ "github.com/hiddify/hiddify-ip-scanner-extension/hiddify_extension"
)
